Linux Users: There are some tools at the web for reading .chm files (try http://xchm.sourceforge.net/).
You can find a html version of this documentation at http://xml.irrlicht3d.org/docu/index.html