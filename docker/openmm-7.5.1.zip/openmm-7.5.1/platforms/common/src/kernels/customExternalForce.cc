COMPUTE_FORCE
real3 force1 = make_real3(-dEdX, -dEdY, -dEdZ);
