######################
OpenMM Developer Guide
######################

.. only:: latex

   .. include:: license.rst

.. toctree::
   :maxdepth: 3
   :numbered:
   
   developer

.. only:: html

   .. include:: license.rst
