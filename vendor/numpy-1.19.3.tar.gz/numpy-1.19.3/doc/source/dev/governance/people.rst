.. _governance-people:

Current steering council and institutional partners
===================================================

Steering council
----------------

* Sebastian Berg

* Jaime Fernández del Río

* Ralf Gommers

* Charles Harris

* Nathaniel Smith

* Julian Taylor

* Pauli Virtanen

* Eric Wieser

* Marten van Kerkwijk

* Stephan Hoyer

* Allan Haldane

* Stefan van der Walt


Emeritus members
----------------

* Travis Oliphant - Project Founder / Emeritus Leader (served: 2005-2012)

* Alex Griffing (served: 2015-2017)


NumFOCUS Subcommittee
---------------------

* Chuck Harris

* Ralf Gommers

* Jaime Fernández del Río

* Sebastian Berg

* External member: Thomas Caswell


Institutional Partners
----------------------

* UC Berkeley (Stefan van der Walt, Sebastian Berg, Warren Weckesser, Ross Barnowski)

* Quansight (Ralf Gommers, Hameer Abbasi, Melissa Weber Mendonça, Mars Lee, Matti Picus)

